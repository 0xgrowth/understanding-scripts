<div class="footer-copyright text-center mt-auto">
    @php
        echo $gs->copyright;
    @endphp
</div>
