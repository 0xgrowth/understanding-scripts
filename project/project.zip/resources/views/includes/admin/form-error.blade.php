<div class="alert alert-danger" style="display: none;" role="alert">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
        <ul class="text-left mb-0">
        </ul>
</div>
