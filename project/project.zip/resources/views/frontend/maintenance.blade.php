<h1>
    @php
        echo $gs->maintain_text;
    @endphp
</h1>